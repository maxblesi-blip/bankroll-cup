# MP Bankroll Cup - Webseite

Eine vollständige Webseite für den MP Bankroll Cup - einen Poker Bankroll Challenge Cup mit Spielerverwaltung, Rangliste und Live Tracking.

## 🎯 Features

- **Discord Login** - OAuth2 Integration mit Discord
- **Rollen-basierte Zugriffskontrolle** - Admin, Mod, Spieler, User
- **Admin/Mod Dashboard** - Spielerverwaltung und Bankroll-Verifikation
- **Öffentliche Rangliste** - Mit Bankroll-Verlauf Diagrammen
- **Livestream Integration** - Zeige aktive Streams aller Spieler
- **Anmeldungsseite** - Informationen und Anmeldeformular
- **Google Sheets Integration** - Backend für Spielerdaten
- **Responsive Design** - Funktioniert auf allen Geräten

## 🚀 Installation

### 1. Voraussetzungen

- Node.js 18+
- npm oder yarn
- Ein Discord Server mit Bot
- Google Cloud Projekt mit Sheets API

### 2. Repository klonen

```bash
git clone <repo-url>
cd bankroll-cup
npm install
```

### 3. Umgebungsvariablen konfigurieren

Erstelle eine `.env.local` Datei im Root-Verzeichnis:

```env
# Discord OAuth
DISCORD_CLIENT_ID=your_client_id_here
DISCORD_CLIENT_SECRET=your_client_secret_here
DISCORD_SERVER_ID=your_server_id_here
DISCORD_TOKEN=your_bot_token_here

# NextAuth
NEXTAUTH_SECRET=generate_with_openssl_rand_base64_32
NEXTAUTH_URL=http://localhost:3000

# Google Sheets
GOOGLE_SHEETS_API_KEY=your_api_key_here
GOOGLE_SHEETS_SPREADSHEET_ID=your_spreadsheet_id_here

# Rollen IDs (von Discord)
ADMIN_ROLE_ID=your_admin_role_id
MOD_ROLE_ID=your_mod_role_id
PLAYER_ROLE_ID=your_player_role_id
```

### 4. Entwicklungsserver starten

```bash
npm run dev
```

Öffne [http://localhost:3000](http://localhost:3000) im Browser.

## 📋 Setup Anleitung

### Discord Bot Setup

1. Gehe zu [Discord Developer Portal](https://discord.com/developers/applications)
2. Erstelle eine neue Application
3. Kopiere die Client ID und Client Secret
4. Unter "OAuth2" → "URL Generator":
   - Wähle "bot" Scope
   - Wähle folgende Permissions:
     - `read:guild_members`
     - `identify`

5. Generiere die OAuth2 URL und autorisiere den Bot auf deinem Server

### Google Sheets Setup

1. Gehe zu [Google Cloud Console](https://console.cloud.google.com/)
2. Erstelle ein neues Projekt
3. Aktiviere die Google Sheets API
4. Erstelle Service Account Credentials
5. Erstelle ein Google Sheet mit folgendem Format:

```
| Name | GGPoker Nickname | Bankroll | Livestream Link | Last Verification |
|------|------------------|----------|-----------------|-------------------|
```

## 🗂️ Projektstruktur

```
bankroll-cup/
├── app/
│   ├── api/
│   │   ├── auth/[...nextauth].ts       # Discord OAuth
│   │   ├── registration/route.ts        # Spieler-Anmeldung
│   │   └── sheets/players/route.ts      # Google Sheets Integration
│   ├── components/
│   │   ├── Navigation.tsx               # Haupt-Navigation
│   │   └── AuthProvider.tsx             # NextAuth Provider
│   ├── admin/
│   │   └── page.tsx                     # Admin Dashboard
│   ├── anmeldung/
│   │   └── page.tsx                     # Anmeldungsseite
│   ├── rangliste/
│   │   └── page.tsx                     # Rangliste mit Charts
│   ├── livestreams/
│   │   └── page.tsx                     # Livestream Seite
│   ├── globals.css                      # Global Styles
│   ├── layout.tsx                       # Root Layout
│   └── page.tsx                         # Homepage
├── .env.local                            # Umgebungsvariablen
├── package.json
├── tailwind.config.js
├── tsconfig.json
└── README.md
```

## 🔐 Authentifizierung & Autorisierung

### Rollen-System

Die Anwendung verwendet Discord Rollen für Berechtigungen:

- **Admin** - Vollzugriff, kann Spieler erstellen/löschen
- **Mod** - Kann Spieler verwalten und Bankrolls verifizieren
- **Player** - Angemeldet, sieht alle öffentlichen Seiten
- **User/Everyone** - Sieht nur öffentliche Seiten

Die Rollen werden automatisch beim Discord Login überprüft.

## 📊 Datenfluss

### Spielerdaten-Synchronisation

```
Google Sheets
    ↓
GET /api/sheets/players
    ↓
Rangliste & Admin Dashboard
```

### Anmeldung

```
Anmeldeformular
    ↓
POST /api/registration
    ↓
Google Sheets (admin: pending)
    ↓
Admin Bestätigung
    ↓
Google Sheets (status: verified)
```

## 🎨 Customization

### Theme anpassen

Bearbeite `tailwind.config.js` um Farben/Schriften anzupassen:

```js
theme: {
  extend: {
    colors: {
      primary: "#your-color",
    }
  }
}
```

### Bankroll Ziel ändern

In `app/rangliste/page.tsx` und anderen Komponenten:

```typescript
const BANKROLL_START = 500;
const BANKROLL_GOAL = 5000;
```

## 📱 API Endpoints

### Authentication
- `GET /api/auth/signin` - Discord Login
- `GET /api/auth/signout` - Logout
- `GET /api/auth/session` - Hole aktuelle Session

### Spieler
- `GET /api/sheets/players` - Alle Spieler
- `POST /api/sheets/players` - Spieler aktualisieren
- `POST /api/registration` - Neue Anmeldung

## 🐛 Troubleshooting

### Discord Login funktioniert nicht
- Überprüfe DISCORD_CLIENT_ID und CLIENT_SECRET
- Stelle sicher dass NEXTAUTH_URL korrekt ist
- Überprüfe Redirect URIs in Discord Developer Portal

### Google Sheets API Fehler
- Überprüfe API Keys und Spreadsheet ID
- Stelle sicher dass die Sheets API aktiviert ist
- Überprüfe Service Account Permissions

### Rollen werden nicht erkannt
- Überprüfe ob die Role IDs korrekt in .env sind
- Stelle sicher dass die Rollen auf dem Discord Server existieren
- Benutzer muss die Discord Rolle zugewiesen haben

## 📝 Deployment

### Vercel Deployment

```bash
npm install -g vercel
vercel
```

Vergesse nicht Environment Variables auf Vercel zu setzen!

### Self-Hosted

```bash
npm run build
npm start
```

## 📞 Support

Bei Fragen oder Fehlern: Öffne ein Issue auf GitHub

## 📄 Lizenz

Privat - Nur für MP Bankroll Cup

---

**Viel Erfolg beim MP Bankroll Cup! 🎰🏆**
