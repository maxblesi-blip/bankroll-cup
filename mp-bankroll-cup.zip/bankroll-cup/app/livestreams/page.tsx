// app/livestreams/page.tsx
"use client";

import { useState, useEffect } from "react";
import { ExternalLink, Radio } from "lucide-react";

interface Livestream {
  id: string;
  playerName: string;
  channel: string;
  url: string;
  thumbnail: string;
  isLive: boolean;
  viewers: number;
  game: string;
}

export default function Livestreams() {
  const [streams, setStreams] = useState<Livestream[]>([]);
  const [allStreams, setAllStreams] = useState<Livestream[]>([]);
  const [loading, setLoading] = useState(true);
  const [filter, setFilter] = useState("live");

  // Mock Daten - würde von Backend kommen
  const mockStreams: Livestream[] = [
    {
      id: "1",
      playerName: "Spieler A",
      channel: "ProPlayer123",
      url: "https://twitch.tv/prostream",
      thumbnail: "https://via.placeholder.com/320x180?text=ProPlayer123",
      isLive: true,
      viewers: 245,
      game: "Texas Hold'em",
    },
    {
      id: "2",
      playerName: "Spieler B",
      channel: "HighRoller99",
      url: "https://twitch.tv/highroller",
      thumbnail: "https://via.placeholder.com/320x180?text=HighRoller99",
      isLive: true,
      viewers: 189,
      game: "Texas Hold'em",
    },
    {
      id: "3",
      playerName: "Spieler C",
      channel: "GrindNinja",
      url: "https://twitch.tv/grind",
      thumbnail: "https://via.placeholder.com/320x180?text=GrindNinja",
      isLive: false,
      viewers: 0,
      game: "Texas Hold'em",
    },
    {
      id: "4",
      playerName: "Spieler D",
      channel: "PokerMaster88",
      url: "https://youtube.com/pokermaster",
      thumbnail: "https://via.placeholder.com/320x180?text=PokerMaster88",
      isLive: true,
      viewers: 456,
      game: "Cash Game",
    },
  ];

  useEffect(() => {
    // In Produktion: Streams von API holen
    const liveStreams = mockStreams.filter((s) => s.isLive);
    setStreams(liveStreams);
    setAllStreams(mockStreams);
    setLoading(false);
  }, []);

  const displayedStreams = filter === "live" ? streams : allStreams;

  return (
    <div className="max-w-7xl mx-auto px-4 py-8">
      <div className="mb-8">
        <h1 className="text-4xl font-bold mb-2">Livestreams</h1>
        <p className="text-slate-400">
          Verfolge die Spieler beim Bankroll-Aufbau live
        </p>
      </div>

      {/* Live Status */}
      <div className="grid md:grid-cols-4 gap-4 mb-8">
        <div className="bg-slate-800 border border-slate-700 rounded-lg p-6">
          <h3 className="text-slate-400 text-sm mb-2">Aktive Streams</h3>
          <p className="text-4xl font-bold text-green-400">{streams.length}</p>
        </div>
        <div className="bg-slate-800 border border-slate-700 rounded-lg p-6">
          <h3 className="text-slate-400 text-sm mb-2">Zuschauer gesamt</h3>
          <p className="text-4xl font-bold text-blue-400">
            {streams.reduce((acc, s) => acc + s.viewers, 0)}
          </p>
        </div>
        <div className="bg-slate-800 border border-slate-700 rounded-lg p-6">
          <h3 className="text-slate-400 text-sm mb-2">Max. Zuschauer</h3>
          <p className="text-4xl font-bold text-purple-400">
            {Math.max(...streams.map((s) => s.viewers), 0)}
          </p>
        </div>
        <div className="bg-slate-800 border border-slate-700 rounded-lg p-6">
          <h3 className="text-slate-400 text-sm mb-2">Registrierte Spieler</h3>
          <p className="text-4xl font-bold text-yellow-400">{allStreams.length}</p>
        </div>
      </div>

      {/* Filter */}
      <div className="bg-slate-800 border border-slate-700 rounded-lg p-4 mb-8">
        <div className="flex gap-3">
          <button
            onClick={() => setFilter("live")}
            className={`px-4 py-2 rounded-lg font-medium transition flex items-center gap-2 ${
              filter === "live"
                ? "bg-green-600 text-white"
                : "bg-slate-700 text-slate-300 hover:bg-slate-600"
            }`}
          >
            <Radio size={18} className="text-green-400" />
            Live ({streams.length})
          </button>
          <button
            onClick={() => setFilter("all")}
            className={`px-4 py-2 rounded-lg font-medium transition ${
              filter === "all"
                ? "bg-blue-600 text-white"
                : "bg-slate-700 text-slate-300 hover:bg-slate-600"
            }`}
          >
            Alle ({allStreams.length})
          </button>
        </div>
      </div>

      {/* Streams Grid */}
      {displayedStreams.length > 0 ? (
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
          {displayedStreams.map((stream) => (
            <a
              key={stream.id}
              href={stream.url}
              target="_blank"
              rel="noopener noreferrer"
              className="group cursor-pointer"
            >
              <div className="bg-slate-800 border border-slate-700 rounded-lg overflow-hidden hover:border-blue-500 transition hover:shadow-lg hover:shadow-blue-500/20">
                {/* Thumbnail */}
                <div className="relative overflow-hidden bg-slate-900 aspect-video">
                  <img
                    src={stream.thumbnail}
                    alt={stream.playerName}
                    className="w-full h-full object-cover group-hover:scale-110 transition duration-300"
                  />
                  {stream.isLive && (
                    <div className="absolute top-3 left-3 bg-red-600 text-white px-3 py-1 rounded-full text-sm font-bold flex items-center gap-2">
                      <Radio size={14} />
                      LIVE
                    </div>
                  )}
                  {stream.isLive && (
                    <div className="absolute bottom-3 right-3 bg-black/80 text-white px-3 py-1 rounded text-sm font-medium">
                      {stream.viewers} Zuschauer
                    </div>
                  )}
                </div>

                {/* Info */}
                <div className="p-4">
                  <h3 className="font-bold text-lg mb-1">{stream.playerName}</h3>
                  <p className="text-slate-400 text-sm mb-3">
                    @{stream.channel}
                  </p>
                  <p className="text-slate-300 text-sm mb-4">{stream.game}</p>

                  <div className="flex items-center justify-between">
                    <span
                      className={`text-xs font-bold px-2 py-1 rounded ${
                        stream.isLive
                          ? "bg-green-600/20 text-green-400"
                          : "bg-slate-700/50 text-slate-400"
                      }`}
                    >
                      {stream.isLive ? "ONLINE" : "OFFLINE"}
                    </span>
                    <ExternalLink
                      size={16}
                      className="text-slate-400 group-hover:text-blue-400 transition"
                    />
                  </div>
                </div>
              </div>
            </a>
          ))}
        </div>
      ) : (
        <div className="bg-slate-800 border border-slate-700 rounded-lg p-12 text-center">
          <p className="text-slate-400 text-lg">
            {filter === "live"
              ? "Momentan sind keine Livestreams aktiv. Schaue später wieder vorbei!"
              : "Keine Livestreams hinterlegt."}
          </p>
        </div>
      )}

      {/* Info Box */}
      <div className="mt-12 bg-gradient-to-r from-blue-900 to-purple-900 border border-blue-700 rounded-lg p-8">
        <h3 className="text-2xl font-bold mb-4">Dein Livestream?</h3>
        <p className="text-slate-300 mb-4">
          Du möchtest deinen Livestream auf unserer Seite anzeigen lassen? Melde
          dich zur Anmeldung an und trage deinen Livestream Link ein. Dieser
          wird dann auf der Livestream Seite automatisch angezeigt wenn du live
          bist!
        </p>
        <a
          href="/anmeldung"
          className="inline-block bg-white text-purple-600 px-6 py-2 rounded-lg font-bold hover:bg-slate-100 transition"
        >
          Zur Anmeldung
        </a>
      </div>
    </div>
  );
}
