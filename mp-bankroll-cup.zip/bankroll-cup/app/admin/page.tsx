// app/admin/page.tsx
"use client";

import { useState, useEffect } from "react";
import { useSession } from "next-auth/react";
import { useRouter } from "next/navigation";
import { Trash2, Plus, CheckCircle, XCircle, Eye } from "lucide-react";

interface Player {
  id: string;
  name: string;
  ggpokerNickname: string;
  bankroll: number;
  livestreamLink?: string;
  lastVerification: string;
  status: "pending" | "verified" | "inactive";
}

interface NewPlayer {
  name: string;
  ggpokerNickname: string;
  bankroll: string;
  livestreamLink: string;
}

export default function AdminPanel() {
  const { data: session } = useSession();
  const router = useRouter();
  const [players, setPlayers] = useState<Player[]>([]);
  const [showAddForm, setShowAddForm] = useState(false);
  const [showVerifyModal, setShowVerifyModal] = useState(false);
  const [selectedPlayer, setSelectedPlayer] = useState<Player | null>(null);
  const [newPlayer, setNewPlayer] = useState<NewPlayer>({
    name: "",
    ggpokerNickname: "",
    bankroll: "",
    livestreamLink: "",
  });
  const [verificationData, setVerificationData] = useState({
    bankroll: "",
    notes: "",
  });

  // Mock Daten
  const mockPlayers: Player[] = [
    {
      id: "1",
      name: "Spieler A",
      ggpokerNickname: "ProPlayer123",
      bankroll: 3500,
      livestreamLink: "https://twitch.tv/prostream",
      lastVerification: "2025-10-22",
      status: "verified",
    },
    {
      id: "2",
      name: "Spieler B",
      ggpokerNickname: "HighRoller99",
      bankroll: 2800,
      lastVerification: "2025-10-22",
      status: "verified",
    },
    {
      id: "3",
      name: "Neuer Spieler",
      ggpokerNickname: "NewPlayer777",
      bankroll: 500,
      lastVerification: "",
      status: "pending",
    },
  ];

  useEffect(() => {
    // Überprüfe ob User ein Mod oder Admin ist
    const user = session?.user as any;
    if (!user || (user.role !== "admin" && user.role !== "mod")) {
      router.push("/");
    }

    setPlayers(mockPlayers);
  }, [session, router]);

  const handleAddPlayer = async (e: React.FormEvent) => {
    e.preventDefault();

    const newPlayerData: Player = {
      id: Date.now().toString(),
      name: newPlayer.name,
      ggpokerNickname: newPlayer.ggpokerNickname,
      bankroll: parseFloat(newPlayer.bankroll) || 500,
      livestreamLink: newPlayer.livestreamLink || undefined,
      lastVerification: new Date().toISOString().split("T")[0],
      status: "verified",
    };

    setPlayers([...players, newPlayerData]);
    setNewPlayer({
      name: "",
      ggpokerNickname: "",
      bankroll: "",
      livestreamLink: "",
    });
    setShowAddForm(false);
  };

  const handleDeletePlayer = (id: string) => {
    if (confirm("Wirklich löschen?")) {
      setPlayers(players.filter((p) => p.id !== id));
    }
  };

  const handleVerifyClick = (player: Player) => {
    setSelectedPlayer(player);
    setVerificationData({
      bankroll: player.bankroll.toString(),
      notes: "",
    });
    setShowVerifyModal(true);
  };

  const handleVerifySubmit = () => {
    if (selectedPlayer) {
      setPlayers(
        players.map((p) =>
          p.id === selectedPlayer.id
            ? {
                ...p,
                bankroll: parseFloat(verificationData.bankroll),
                lastVerification: new Date().toISOString().split("T")[0],
                status: "verified",
              }
            : p
        )
      );
      setShowVerifyModal(false);
      setSelectedPlayer(null);
    }
  };

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target;
    setNewPlayer((prev) => ({
      ...prev,
      [name]: value,
    }));
  };

  const user = session?.user as any;
  const isAdmin = user?.role === "admin";

  return (
    <div className="max-w-7xl mx-auto px-4 py-8">
      <div className="mb-8">
        <h1 className="text-4xl font-bold mb-2">Admin Panel</h1>
        <p className="text-slate-400">
          Verwalte Spieler und verifiziere ihre Bankrolls
        </p>
      </div>

      {/* Add Player Button */}
      <div className="mb-8 flex gap-4">
        <button
          onClick={() => setShowAddForm(!showAddForm)}
          className="flex items-center gap-2 bg-green-600 hover:bg-green-700 px-6 py-3 rounded-lg font-bold transition"
        >
          <Plus size={20} />
          Spieler hinzufügen
        </button>
      </div>

      {/* Add Player Form */}
      {showAddForm && (
        <div className="bg-slate-800 border border-slate-700 rounded-lg p-8 mb-8">
          <h2 className="text-2xl font-bold mb-6">Neuen Spieler hinzufügen</h2>
          <form onSubmit={handleAddPlayer} className="grid md:grid-cols-2 gap-6">
            <div>
              <label className="block text-sm font-bold mb-2">Name</label>
              <input
                type="text"
                name="name"
                value={newPlayer.name}
                onChange={handleInputChange}
                required
                className="w-full bg-slate-900 border border-slate-700 rounded-lg px-4 py-3 text-white focus:outline-none focus:border-blue-500"
                placeholder="Spieler Name"
              />
            </div>
            <div>
              <label className="block text-sm font-bold mb-2">
                GGPoker Nickname
              </label>
              <input
                type="text"
                name="ggpokerNickname"
                value={newPlayer.ggpokerNickname}
                onChange={handleInputChange}
                required
                className="w-full bg-slate-900 border border-slate-700 rounded-lg px-4 py-3 text-white focus:outline-none focus:border-blue-500"
                placeholder="GGPoker Username"
              />
            </div>
            <div>
              <label className="block text-sm font-bold mb-2">Bankroll</label>
              <input
                type="number"
                name="bankroll"
                value={newPlayer.bankroll}
                onChange={handleInputChange}
                defaultValue="500"
                className="w-full bg-slate-900 border border-slate-700 rounded-lg px-4 py-3 text-white focus:outline-none focus:border-blue-500"
                placeholder="500"
              />
            </div>
            <div>
              <label className="block text-sm font-bold mb-2">
                Livestream Link (optional)
              </label>
              <input
                type="url"
                name="livestreamLink"
                value={newPlayer.livestreamLink}
                onChange={handleInputChange}
                className="w-full bg-slate-900 border border-slate-700 rounded-lg px-4 py-3 text-white focus:outline-none focus:border-blue-500"
                placeholder="https://twitch.tv/..."
              />
            </div>
            <div className="md:col-span-2 flex gap-4">
              <button
                type="submit"
                className="bg-green-600 hover:bg-green-700 px-6 py-3 rounded-lg font-bold transition"
              >
                Hinzufügen
              </button>
              <button
                type="button"
                onClick={() => setShowAddForm(false)}
                className="bg-slate-700 hover:bg-slate-600 px-6 py-3 rounded-lg font-bold transition"
              >
                Abbrechen
              </button>
            </div>
          </form>
        </div>
      )}

      {/* Players Table */}
      <div className="bg-slate-800 border border-slate-700 rounded-lg overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead>
              <tr className="bg-slate-900 border-b border-slate-700">
                <th className="px-6 py-4 text-left font-bold text-slate-300">
                  Name
                </th>
                <th className="px-6 py-4 text-left font-bold text-slate-300">
                  GGPoker
                </th>
                <th className="px-6 py-4 text-right font-bold text-slate-300">
                  Bankroll
                </th>
                <th className="px-6 py-4 text-left font-bold text-slate-300">
                  Letzte Verifikation
                </th>
                <th className="px-6 py-4 text-left font-bold text-slate-300">
                  Status
                </th>
                <th className="px-6 py-4 text-center font-bold text-slate-300">
                  Aktionen
                </th>
              </tr>
            </thead>
            <tbody>
              {players.map((player) => (
                <tr
                  key={player.id}
                  className="border-b border-slate-700 hover:bg-slate-700/50 transition"
                >
                  <td className="px-6 py-4 font-bold">{player.name}</td>
                  <td className="px-6 py-4 text-slate-300">
                    {player.ggpokerNickname}
                  </td>
                  <td className="px-6 py-4 text-right font-bold">
                    €{player.bankroll}
                  </td>
                  <td className="px-6 py-4 text-slate-400">
                    {player.lastVerification
                      ? new Date(player.lastVerification).toLocaleDateString(
                          "de-DE"
                        )
                      : "Nicht verifiziert"}
                  </td>
                  <td className="px-6 py-4">
                    <span
                      className={`inline-flex items-center gap-2 px-3 py-1 rounded-full text-sm font-bold ${
                        player.status === "verified"
                          ? "bg-green-600/20 text-green-400"
                          : player.status === "pending"
                          ? "bg-yellow-600/20 text-yellow-400"
                          : "bg-slate-700/50 text-slate-400"
                      }`}
                    >
                      {player.status === "verified" ? (
                        <>
                          <CheckCircle size={14} />
                          Verifiziert
                        </>
                      ) : player.status === "pending" ? (
                        <>
                          <Eye size={14} />
                          Pending
                        </>
                      ) : (
                        <>
                          <XCircle size={14} />
                          Inaktiv
                        </>
                      )}
                    </span>
                  </td>
                  <td className="px-6 py-4">
                    <div className="flex gap-3 justify-center">
                      <button
                        onClick={() => handleVerifyClick(player)}
                        className="bg-blue-600 hover:bg-blue-700 p-2 rounded-lg transition"
                        title="Verifizieren"
                      >
                        <CheckCircle size={18} />
                      </button>
                      {isAdmin && (
                        <button
                          onClick={() => handleDeletePlayer(player.id)}
                          className="bg-red-600 hover:bg-red-700 p-2 rounded-lg transition"
                          title="Löschen"
                        >
                          <Trash2 size={18} />
                        </button>
                      )}
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Verify Modal */}
      {showVerifyModal && selectedPlayer && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50">
          <div className="bg-slate-800 border border-slate-700 rounded-lg p-8 max-w-md w-full">
            <h2 className="text-2xl font-bold mb-6">
              {selectedPlayer.name} verifizieren
            </h2>

            <div className="space-y-6">
              <div>
                <label className="block text-sm font-bold mb-2">
                  Bankroll aktualisieren
                </label>
                <input
                  type="number"
                  value={verificationData.bankroll}
                  onChange={(e) =>
                    setVerificationData({
                      ...verificationData,
                      bankroll: e.target.value,
                    })
                  }
                  className="w-full bg-slate-900 border border-slate-700 rounded-lg px-4 py-3 text-white focus:outline-none focus:border-blue-500"
                />
              </div>

              <div>
                <label className="block text-sm font-bold mb-2">
                  Notizen (optional)
                </label>
                <textarea
                  value={verificationData.notes}
                  onChange={(e) =>
                    setVerificationData({
                      ...verificationData,
                      notes: e.target.value,
                    })
                  }
                  className="w-full bg-slate-900 border border-slate-700 rounded-lg px-4 py-3 text-white focus:outline-none focus:border-blue-500 resize-none"
                  rows={3}
                  placeholder="z.B. Screenshot überprüft, Wert bestätigt"
                />
              </div>

              <div className="flex gap-4">
                <button
                  onClick={handleVerifySubmit}
                  className="flex-1 bg-green-600 hover:bg-green-700 px-4 py-2 rounded-lg font-bold transition"
                >
                  Verifizieren
                </button>
                <button
                  onClick={() => setShowVerifyModal(false)}
                  className="flex-1 bg-slate-700 hover:bg-slate-600 px-4 py-2 rounded-lg font-bold transition"
                >
                  Abbrechen
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
