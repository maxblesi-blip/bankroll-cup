// app/components/Navigation.tsx
"use client";

import Link from "next/link";
import { useState, useRef, useEffect } from "react";
import { useSession, signIn, signOut } from "next-auth/react";
import { Menu, LogOut, Settings } from "lucide-react";

interface User {
  name: string | null;
  image: string | null;
  role: "admin" | "mod" | "player" | "user" | null;
}

export default function Navigation() {
  const { data: session } = useSession();
  const [isOpen, setIsOpen] = useState(false);
  const [isDropdownOpen, setIsDropdownOpen] = useState(false);
  const dropdownRef = useRef<HTMLDivElement>(null);

  const user = session?.user as User | undefined;
  const isAdmin = user?.role === "admin";
  const isMod = user?.role === "mod" || isAdmin;

  useEffect(() => {
    function handleClickOutside(event: MouseEvent) {
      if (
        dropdownRef.current &&
        !dropdownRef.current.contains(event.target as Node)
      ) {
        setIsDropdownOpen(false);
      }
    }

    document.addEventListener("mousedown", handleClickOutside);
    return () => document.removeEventListener("mousedown", handleClickOutside);
  }, []);

  return (
    <nav className="fixed top-0 w-full bg-slate-900 border-b border-slate-700 z-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center h-20">
          {/* Logo */}
          <Link href="/" className="flex items-center gap-2">
            <div className="text-2xl font-bold bg-gradient-to-r from-blue-400 to-purple-600 bg-clip-text text-transparent">
              MP Bankroll Cup
            </div>
          </Link>

          {/* Desktop Navigation */}
          <div className="hidden md:flex items-center gap-8">
            <Link
              href="/"
              className="text-slate-300 hover:text-white transition"
            >
              Home
            </Link>
            <Link
              href="/rangliste"
              className="text-slate-300 hover:text-white transition"
            >
              Rangliste
            </Link>
            <Link
              href="/livestreams"
              className="text-slate-300 hover:text-white transition"
            >
              Livestreams
            </Link>
            <Link
              href="/anmeldung"
              className="text-slate-300 hover:text-white transition"
            >
              Anmeldung
            </Link>
          </div>

          {/* User Menu */}
          <div className="flex items-center gap-4">
            {session && user ? (
              <div className="relative" ref={dropdownRef}>
                <button
                  onClick={() => setIsDropdownOpen(!isDropdownOpen)}
                  className="flex items-center gap-3 hover:bg-slate-800 px-3 py-2 rounded-lg transition"
                >
                  {user.image && (
                    <img
                      src={user.image}
                      alt={user.name || "User"}
                      className="w-8 h-8 rounded-full border border-slate-600"
                    />
                  )}
                  <span className="text-sm font-medium">{user.name}</span>
                  <span className="text-xs bg-blue-600 px-2 py-1 rounded">
                    {user.role?.toUpperCase() || "USER"}
                  </span>
                </button>

                {/* Dropdown Menu */}
                {isDropdownOpen && (
                  <div className="absolute right-0 mt-2 w-48 bg-slate-800 border border-slate-700 rounded-lg shadow-lg">
                    {(isMod || isAdmin) && (
                      <>
                        <Link
                          href="/admin"
                          className="flex items-center gap-2 px-4 py-3 hover:bg-slate-700 transition border-b border-slate-700"
                        >
                          <Settings size={16} />
                          Admin Panel
                        </Link>
                      </>
                    )}
                    <button
                      onClick={() => signOut()}
                      className="w-full flex items-center gap-2 px-4 py-3 hover:bg-slate-700 transition text-red-400"
                    >
                      <LogOut size={16} />
                      Logout
                    </button>
                  </div>
                )}
              </div>
            ) : (
              <button
                onClick={() => signIn("discord")}
                className="bg-indigo-600 hover:bg-indigo-700 px-4 py-2 rounded-lg font-medium transition"
              >
                Discord Login
              </button>
            )}

            {/* Mobile menu button */}
            <button
              onClick={() => setIsOpen(!isOpen)}
              className="md:hidden p-2"
            >
              <Menu size={24} />
            </button>
          </div>
        </div>

        {/* Mobile Navigation */}
        {isOpen && (
          <div className="md:hidden pb-4 space-y-2">
            <Link
              href="/"
              className="block px-4 py-2 text-slate-300 hover:text-white hover:bg-slate-800 rounded transition"
            >
              Home
            </Link>
            <Link
              href="/rangliste"
              className="block px-4 py-2 text-slate-300 hover:text-white hover:bg-slate-800 rounded transition"
            >
              Rangliste
            </Link>
            <Link
              href="/livestreams"
              className="block px-4 py-2 text-slate-300 hover:text-white hover:bg-slate-800 rounded transition"
            >
              Livestreams
            </Link>
            <Link
              href="/anmeldung"
              className="block px-4 py-2 text-slate-300 hover:text-white hover:bg-slate-800 rounded transition"
            >
              Anmeldung
            </Link>
          </div>
        )}
      </div>
    </nav>
  );
}
