// app/anmeldung/page.tsx
"use client";

import { useState } from "react";
import { useSession } from "next-auth/react";
import { CheckCircle, AlertCircle } from "lucide-react";

interface FormData {
  name: string;
  ggpokerNickname: string;
  livestreamLink: string;
  message: string;
}

export default function Anmeldung() {
  const { data: session } = useSession();
  const [formData, setFormData] = useState<FormData>({
    name: "",
    ggpokerNickname: "",
    livestreamLink: "",
    message: "",
  });
  const [submitted, setSubmitted] = useState(false);
  const [loading, setLoading] = useState(false);

  const handleChange = (
    e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>
  ) => {
    const { name, value } = e.target;
    setFormData((prev) => ({
      ...prev,
      [name]: value,
    }));
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);

    try {
      // In Produktion: An Backend-API senden
      const response = await fetch("/api/registration", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          ...formData,
          userId: session?.user?.email,
        }),
      });

      if (response.ok) {
        setSubmitted(true);
        setFormData({
          name: "",
          ggpokerNickname: "",
          livestreamLink: "",
          message: "",
        });

        // Nach 3 Sekunden Reset
        setTimeout(() => {
          setSubmitted(false);
        }, 3000);
      }
    } catch (error) {
      console.error("Anmeldung fehlgeschlagen:", error);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="max-w-6xl mx-auto px-4 py-8">
      <div className="mb-12">
        <h1 className="text-4xl font-bold mb-2">MP Bankroll Cup Anmeldung</h1>
        <p className="text-slate-400">
          Tritt dem 1. MP Bankroll Cup bei und stelle deine Pokerfähigkeiten
          unter Beweis
        </p>
      </div>

      <div className="grid md:grid-cols-3 gap-8">
        {/* Info Section */}
        <div className="md:col-span-1 space-y-6">
          {/* How it works */}
          <div className="bg-slate-800 border border-slate-700 rounded-lg p-6">
            <h2 className="text-xl font-bold mb-4">Wie funktioniert es?</h2>
            <div className="space-y-4">
              <div className="flex gap-3">
                <div className="flex-shrink-0 w-8 h-8 bg-blue-600 rounded-full flex items-center justify-center font-bold text-sm">
                  1
                </div>
                <div>
                  <h3 className="font-bold text-sm">Anmelden</h3>
                  <p className="text-slate-400 text-sm">
                    Fülle das Formular mit deinen Daten aus
                  </p>
                </div>
              </div>
              <div className="flex gap-3">
                <div className="flex-shrink-0 w-8 h-8 bg-purple-600 rounded-full flex items-center justify-center font-bold text-sm">
                  2
                </div>
                <div>
                  <h3 className="font-bold text-sm">Bestätigung</h3>
                  <p className="text-slate-400 text-sm">
                    Admin/Mod bestätigt deine Anmeldung
                  </p>
                </div>
              </div>
              <div className="flex gap-3">
                <div className="flex-shrink-0 w-8 h-8 bg-yellow-600 rounded-full flex items-center justify-center font-bold text-sm">
                  3
                </div>
                <div>
                  <h3 className="font-bold text-sm">Starten</h3>
                  <p className="text-slate-400 text-sm">
                    Du startest mit 500€ und versuchst, diese zu 5.000€ zu
                    bringen
                  </p>
                </div>
              </div>
              <div className="flex gap-3">
                <div className="flex-shrink-0 w-8 h-8 bg-green-600 rounded-full flex items-center justify-center font-bold text-sm">
                  4
                </div>
                <div>
                  <h3 className="font-bold text-sm">Verifikation</h3>
                  <p className="text-slate-400 text-sm">
                    Deine Bankroll wird wöchentlich verifiziert
                  </p>
                </div>
              </div>
            </div>
          </div>

          {/* Requirements */}
          <div className="bg-slate-800 border border-slate-700 rounded-lg p-6">
            <h2 className="text-xl font-bold mb-4">Anforderungen</h2>
            <ul className="space-y-3 text-sm text-slate-300">
              <li className="flex gap-2">
                <CheckCircle size={16} className="text-green-400 flex-shrink-0" />
                <span>Discord Account auf unserem Server</span>
              </li>
              <li className="flex gap-2">
                <CheckCircle size={16} className="text-green-400 flex-shrink-0" />
                <span>GGPoker Account</span>
              </li>
              <li className="flex gap-2">
                <CheckCircle size={16} className="text-green-400 flex-shrink-0" />
                <span>Bankroll von 500€ verfügbar</span>
              </li>
              <li className="flex gap-2">
                <CheckCircle size={16} className="text-green-400 flex-shrink-0" />
                <span>Bereitschaft zur wöchentlichen Verifikation</span>
              </li>
              <li className="flex gap-2">
                <CheckCircle size={16} className="text-green-400 flex-shrink-0" />
                <span>Fair Play und transparente Daten</span>
              </li>
            </ul>
          </div>

          {/* Important Notes */}
          <div className="bg-amber-950 border border-amber-700 rounded-lg p-6">
            <div className="flex gap-3">
              <AlertCircle className="text-amber-400 flex-shrink-0" />
              <div>
                <h3 className="font-bold mb-2">Wichtig</h3>
                <p className="text-sm text-amber-100">
                  Nach Anmeldung wird dein Account von einem Admin/Mod überprüft.
                  Dies kann bis zu 24 Stunden dauern.
                </p>
              </div>
            </div>
          </div>
        </div>

        {/* Form Section */}
        <div className="md:col-span-2">
          <div className="bg-slate-800 border border-slate-700 rounded-lg p-8">
            <h2 className="text-2xl font-bold mb-6">Anmeldeformular</h2>

            {submitted ? (
              <div className="bg-green-600/20 border border-green-600 rounded-lg p-8 text-center">
                <CheckCircle size={48} className="text-green-400 mx-auto mb-4" />
                <h3 className="text-xl font-bold mb-2">Erfolgreich angemeldet!</h3>
                <p className="text-slate-300">
                  Deine Anmeldung wurde eingereicht. Ein Admin/Mod wird diese in
                  Kürze überprüfen.
                </p>
              </div>
            ) : (
              <form onSubmit={handleSubmit} className="space-y-6">
                {/* Name */}
                <div>
                  <label className="block text-sm font-bold mb-2">
                    Dein Name
                  </label>
                  <input
                    type="text"
                    name="name"
                    value={formData.name}
                    onChange={handleChange}
                    required
                    className="w-full bg-slate-900 border border-slate-700 rounded-lg px-4 py-3 text-white focus:outline-none focus:border-blue-500 transition"
                    placeholder="z.B. Max Mustermann"
                  />
                </div>

                {/* GGPoker Nickname */}
                <div>
                  <label className="block text-sm font-bold mb-2">
                    GGPoker Nickname
                  </label>
                  <input
                    type="text"
                    name="ggpokerNickname"
                    value={formData.ggpokerNickname}
                    onChange={handleChange}
                    required
                    className="w-full bg-slate-900 border border-slate-700 rounded-lg px-4 py-3 text-white focus:outline-none focus:border-blue-500 transition"
                    placeholder="Dein GGPoker Spielername"
                  />
                  <p className="text-slate-400 text-sm mt-2">
                    Dies muss genau so sein wie auf GGPoker (mit gleicher
                    Schreibweise)
                  </p>
                </div>

                {/* Livestream Link */}
                <div>
                  <label className="block text-sm font-bold mb-2">
                    Livestream Link (optional)
                  </label>
                  <input
                    type="url"
                    name="livestreamLink"
                    value={formData.livestreamLink}
                    onChange={handleChange}
                    className="w-full bg-slate-900 border border-slate-700 rounded-lg px-4 py-3 text-white focus:outline-none focus:border-blue-500 transition"
                    placeholder="z.B. https://twitch.tv/deinkanal"
                  />
                  <p className="text-slate-400 text-sm mt-2">
                    Falls du streamen wirst, trage hier deinen Link ein
                  </p>
                </div>

                {/* Message */}
                <div>
                  <label className="block text-sm font-bold mb-2">
                    Nachricht (optional)
                  </label>
                  <textarea
                    name="message"
                    value={formData.message}
                    onChange={handleChange}
                    className="w-full bg-slate-900 border border-slate-700 rounded-lg px-4 py-3 text-white focus:outline-none focus:border-blue-500 transition resize-none"
                    rows={4}
                    placeholder="z.B. Warum möchtest du teilnehmen?"
                  ></textarea>
                </div>

                {/* Discord Login Notice */}
                {!session && (
                  <div className="bg-yellow-600/20 border border-yellow-600 rounded-lg p-4">
                    <p className="text-yellow-100 text-sm">
                      ⚠️ Du musst mit Discord angemeldet sein um dich anzumelden.
                      Nutze den Login Button oben rechts.
                    </p>
                  </div>
                )}

                {/* Submit Button */}
                <button
                  type="submit"
                  disabled={!session || loading}
                  className={`w-full py-3 rounded-lg font-bold text-lg transition ${
                    session && !loading
                      ? "bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-700 hover:to-purple-700 text-white cursor-pointer"
                      : "bg-slate-700 text-slate-400 cursor-not-allowed"
                  }`}
                >
                  {loading ? "Wird übermittelt..." : "Anmelden"}
                </button>

                {/* Terms */}
                <p className="text-slate-400 text-xs text-center">
                  Durch die Anmeldung akzeptierst du unsere Regeln und Richtlinien
                  bezüglich Fair Play und Transparenz.
                </p>
              </form>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
