// app/api/sheets/players/route.ts
import { NextRequest, NextResponse } from "next/server";

// Diese Route würde Google Sheets API verwenden um Spielerdaten zu holen
export async function GET(request: NextRequest) {
  try {
    // In Produktion: Hier würde man Google Sheets API aufrufen
    // const sheets = google.sheets({ version: 'v4', auth: authClient });
    // const response = await sheets.spreadsheets.values.get({
    //   spreadsheetId: process.env.GOOGLE_SHEETS_SPREADSHEET_ID,
    //   range: 'Players!A:G',
    // });

    // Mock-Daten für Development
    const mockPlayers = [
      {
        id: "1",
        name: "Spieler A",
        ggpokerNickname: "ProPlayer123",
        bankroll: 3500,
        livestreamLink: "https://twitch.tv/prostream",
        lastVerification: "2025-10-22",
      },
      {
        id: "2",
        name: "Spieler B",
        ggpokerNickname: "HighRoller99",
        bankroll: 2800,
        livestreamLink: "",
        lastVerification: "2025-10-22",
      },
    ];

    return NextResponse.json({
      success: true,
      data: mockPlayers,
    });
  } catch (error) {
    console.error("Fehler beim Abrufen von Google Sheets:", error);
    return NextResponse.json(
      { error: "Fehler beim Abrufen der Spielerdaten" },
      { status: 500 }
    );
  }
}

// POST - Aktualisiere Spielerdaten in Google Sheets
export async function POST(request: NextRequest) {
  try {
    const data = await request.json();

    // In Produktion: Google Sheets API zum Schreiben verwenden
    // await sheets.spreadsheets.values.update({...})

    return NextResponse.json({
      success: true,
      message: "Spielerdaten aktualisiert",
    });
  } catch (error) {
    console.error("Fehler beim Aktualisieren:", error);
    return NextResponse.json(
      { error: "Fehler beim Aktualisieren der Spielerdaten" },
      { status: 500 }
    );
  }
}
