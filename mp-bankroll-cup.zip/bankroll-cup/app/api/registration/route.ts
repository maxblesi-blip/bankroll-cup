// app/api/registration/route.ts
import { NextRequest, NextResponse } from "next/server";

export async function POST(request: NextRequest) {
  try {
    const data = await request.json();

    // Validierung
    if (!data.name || !data.ggpokerNickname) {
      return NextResponse.json(
        { error: "Name und GGPoker Nickname sind erforderlich" },
        { status: 400 }
      );
    }

    // In Produktion: Hier würde man die Daten in eine Datenbank speichern
    // oder an Google Sheets schreiben
    console.log("Neue Anmeldung:", data);

    // Mock: Speichere in einer JSON Datei oder Datenbank
    // Für jetzt: Erfolgreiche Antwort
    return NextResponse.json(
      {
        success: true,
        message: "Anmeldung erfolgreich eingereicht",
        id: Math.random().toString(36).substr(2, 9),
      },
      { status: 201 }
    );
  } catch (error) {
    console.error("Registrierungsfehler:", error);
    return NextResponse.json(
      { error: "Fehler bei der Anmeldung" },
      { status: 500 }
    );
  }
}

// GET - Rufe alle Anmeldungen ab (nur Admin)
export async function GET(request: NextRequest) {
  try {
    // In Produktion: Authentifizierung überprüfen und nur Admin erlauben
    const registrations = [];

    // Mock-Daten
    return NextResponse.json(
      {
        registrations: registrations,
      },
      { status: 200 }
    );
  } catch (error) {
    return NextResponse.json(
      { error: "Fehler beim Abrufen der Anmeldungen" },
      { status: 500 }
    );
  }
}
