// app/api/auth/[...nextauth].ts
import NextAuth from "next-auth";
import DiscordProvider from "next-auth/providers/discord";
import { JWT } from "next-auth/jwt";
import { Session } from "next-auth";

async function getUserRoleFromDiscord(userId: string): Promise<string> {
  // Diese Funktion sollte Discord API aufrufen um die Rollen zu überprüfen
  // Für jetzt: Mock-Implementierung
  const adminIds = process.env.ADMIN_ROLE_ID?.split(",") || [];
  const modIds = process.env.MOD_ROLE_ID?.split(",") || [];

  // Dies ist eine Platzhalter-Logik - Sie müssen Discord API Integration implementieren
  try {
    const response = await fetch(
      `https://discordapp.com/api/users/${userId}`,
      {
        headers: {
          Authorization: `Bot ${process.env.DISCORD_TOKEN}`,
        },
      }
    );

    if (!response.ok) return "user";

    // Hier würde man die Serverrollen überprüfen
    // Für diesen Prototyp: Standard-Benutzer
    return "player";
  } catch (error) {
    console.error("Error fetching user role:", error);
    return "user";
  }
}

const handler = NextAuth({
  providers: [
    DiscordProvider({
      clientId: process.env.DISCORD_CLIENT_ID || "",
      clientSecret: process.env.DISCORD_CLIENT_SECRET || "",
      allowDangerousEmailAccountLinking: true,
    }),
  ],
  callbacks: {
    async jwt({ token, account }) {
      if (account) {
        token.accessToken = account.access_token;
        token.role = await getUserRoleFromDiscord(token.sub || "");
      }
      return token;
    },
    async session({ session, token }) {
      if (session.user) {
        (session.user as any).role = token.role;
      }
      return session;
    },
  },
  pages: {
    signIn: "/auth/signin",
  },
});

export { handler as GET, handler as POST };
