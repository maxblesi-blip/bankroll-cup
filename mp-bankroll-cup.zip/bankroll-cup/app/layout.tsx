// app/layout.tsx
import type { Metadata } from "next";
import "./globals.css";
import Navigation from "./components/Navigation";
import AuthProvider from "./components/AuthProvider";

export const metadata: Metadata = {
  title: "MP Bankroll Cup",
  description: "1. MP Bankroll Cup - Poker Bankroll Tracking",
};

export default function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <html lang="de">
      <body className="bg-slate-950 text-white">
        <AuthProvider>
          <Navigation />
          <main className="min-h-screen pt-20">
            {children}
          </main>
          <footer className="bg-slate-900 border-t border-slate-700 mt-20">
            <div className="max-w-7xl mx-auto px-4 py-8 text-center text-slate-400">
              <p>&copy; 2025 MP Bankroll Cup. Alle Rechte vorbehalten.</p>
            </div>
          </footer>
        </AuthProvider>
      </body>
    </html>
  );
}
