// app/page.tsx
"use client";

import Link from "next/link";
import { Trophy, Users, TrendingUp, Zap } from "lucide-react";

export default function Home() {
  return (
    <div className="min-h-screen bg-gradient-to-b from-slate-950 to-slate-900">
      {/* Hero Section */}
      <div className="max-w-6xl mx-auto px-4 py-20">
        <div className="text-center mb-16">
          <div className="inline-block mb-6">
            <Trophy className="w-20 h-20 text-yellow-400" />
          </div>
          <h1 className="text-5xl md:text-7xl font-bold mb-6 bg-gradient-to-r from-yellow-400 via-purple-500 to-blue-500 bg-clip-text text-transparent">
            MP Bankroll Cup
          </h1>
          <p className="text-2xl text-slate-300 mb-8">
            1. Auflage - Das größte Bankroll-Challenge-Turnier
          </p>
        </div>

        {/* Main Info Card */}
        <div className="bg-gradient-to-br from-slate-800 to-slate-900 border border-purple-600 rounded-2xl p-12 mb-16 shadow-2xl">
          <div className="grid md:grid-cols-2 gap-12">
            <div>
              <h2 className="text-3xl font-bold mb-6 text-white">
                Das Ziel
              </h2>
              <p className="text-lg text-slate-300 leading-relaxed mb-6">
                Spieler starten mit einer Bankroll von{" "}
                <span className="text-yellow-400 font-bold">500€</span> und
                versuchen, diese so schnell wie möglich auf{" "}
                <span className="text-yellow-400 font-bold">5.000€</span> zu
                bringen.
              </p>
              <p className="text-lg text-slate-300 leading-relaxed">
                Der erste Spieler, der sein Ziel erreicht, gewinnt den{" "}
                <span className="text-purple-400 font-bold">
                  MP Bankroll Cup
                </span>{" "}
                und wird in die Hall of Fame aufgenommen!
              </p>
            </div>
            <div className="bg-slate-950 border border-slate-700 rounded-xl p-8">
              <div className="space-y-6">
                <div className="flex items-center gap-4">
                  <div className="bg-yellow-400 text-slate-950 rounded-full w-12 h-12 flex items-center justify-center font-bold">
                    $
                  </div>
                  <div>
                    <p className="text-slate-400 text-sm">Startbankroll</p>
                    <p className="text-2xl font-bold">500€</p>
                  </div>
                </div>
                <div className="flex items-center gap-4">
                  <div className="bg-purple-600 text-white rounded-full w-12 h-12 flex items-center justify-center font-bold">
                    🎯
                  </div>
                  <div>
                    <p className="text-slate-400 text-sm">Ziel</p>
                    <p className="text-2xl font-bold">5.000€</p>
                  </div>
                </div>
                <div className="flex items-center gap-4">
                  <div className="bg-blue-600 text-white rounded-full w-12 h-12 flex items-center justify-center font-bold">
                    10x
                  </div>
                  <div>
                    <p className="text-slate-400 text-sm">Multiplikator</p>
                    <p className="text-2xl font-bold">10x ROI</p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Features Section */}
        <div className="grid md:grid-cols-3 gap-6 mb-16">
          <div className="bg-slate-800 border border-slate-700 rounded-xl p-8 hover:border-blue-500 transition">
            <TrendingUp className="w-12 h-12 text-blue-400 mb-4" />
            <h3 className="text-xl font-bold mb-3">Live Tracking</h3>
            <p className="text-slate-300">
              Verfolge deine Bankroll und die aller Spieler in Echtzeit auf
              unserer Rangliste.
            </p>
          </div>

          <div className="bg-slate-800 border border-slate-700 rounded-xl p-8 hover:border-purple-500 transition">
            <Users className="w-12 h-12 text-purple-400 mb-4" />
            <h3 className="text-xl font-bold mb-3">Community</h3>
            <p className="text-slate-300">
              Tausch dich mit anderen Spielern aus und verfolge deren Fortschritt
              im Cup.
            </p>
          </div>

          <div className="bg-slate-800 border border-slate-700 rounded-xl p-8 hover:border-yellow-500 transition">
            <Zap className="w-12 h-12 text-yellow-400 mb-4" />
            <h3 className="text-xl font-bold mb-3">Wöchentliche Verifikation</h3>
            <p className="text-slate-300">
              Alle Bankrolls werden wöchentlich von unseren Mods verifiziert
              für Fair Play.
            </p>
          </div>
        </div>

        {/* CTA Section */}
        <div className="bg-gradient-to-r from-blue-600 to-purple-600 rounded-2xl p-12 text-center">
          <h2 className="text-3xl font-bold mb-4">Bereit zum Spielen?</h2>
          <p className="text-lg text-blue-100 mb-8">
            Melde dich jetzt an und starte deine Bankroll-Challenge!
          </p>
          <Link
            href="/anmeldung"
            className="inline-block bg-white text-purple-600 px-8 py-4 rounded-lg font-bold text-lg hover:bg-slate-100 transition transform hover:scale-105"
          >
            Jetzt Anmelden
          </Link>
        </div>

        {/* Rules Section */}
        <div className="mt-20 bg-slate-800 border border-slate-700 rounded-xl p-12">
          <h2 className="text-3xl font-bold mb-8 text-center">Regeln</h2>
          <div className="grid md:grid-cols-2 gap-8">
            <div>
              <h3 className="text-xl font-bold mb-4 text-blue-400">Allgemein</h3>
              <ul className="space-y-3 text-slate-300">
                <li className="flex gap-3">
                  <span className="text-yellow-400">✓</span>
                  <span>Spieler starten mit 500€ Bankroll</span>
                </li>
                <li className="flex gap-3">
                  <span className="text-yellow-400">✓</span>
                  <span>Ziel ist 5.000€ zu erreichen</span>
                </li>
                <li className="flex gap-3">
                  <span className="text-yellow-400">✓</span>
                  <span>Nur GGPoker als zugelassener Poker Room</span>
                </li>
              </ul>
            </div>
            <div>
              <h3 className="text-xl font-bold mb-4 text-purple-400">
                Verifikation
              </h3>
              <ul className="space-y-3 text-slate-300">
                <li className="flex gap-3">
                  <span className="text-yellow-400">✓</span>
                  <span>Wöchentliche Bankroll-Überprüfung</span>
                </li>
                <li className="flex gap-3">
                  <span className="text-yellow-400">✓</span>
                  <span>Screenshots beim Cashout erforderlich</span>
                </li>
                <li className="flex gap-3">
                  <span className="text-yellow-400">✓</span>
                  <span>Transparenz und Fair Play ist Pflicht</span>
                </li>
              </ul>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
